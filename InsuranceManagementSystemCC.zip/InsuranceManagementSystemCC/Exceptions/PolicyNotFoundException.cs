﻿using InsuranceManagementSystemCC.Dao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceManagementSystemCC.Exceptions
{
    internal class PolicyNotFoundException:Exception
    {
        public PolicyNotFoundException(string message) : base(message)
        {


        }
        public static void PolicyNotFound(int policyId)
        {
            InsuranceServiceImpl  insuranceServiceImpl = new InsuranceServiceImpl();
            if (!insuranceServiceImpl.PolicyNotExists(policyId))
                throw new PolicyNotFoundException("Customer not found!!!");


        }

       
    }
}
