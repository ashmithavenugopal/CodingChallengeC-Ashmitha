﻿using InsuranceManagementSystemCC.Models;
using InsuranceManagementSystemCC.Utility;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceManagementSystemCC.Dao
{
    public class InsuranceServiceImpl : IPolicyService
    {
        SqlConnection connect = null;
        SqlCommand cmd = null;

        public InsuranceServiceImpl()
        {
            connect = new SqlConnection(DBConnection.GetConnectionString());
            cmd = new SqlCommand();
        }
        public bool CreatePolicy(Policy policy)
        {
            
            cmd.CommandText = "Insert into PPolicy(policyName) values(@Pname)";
            cmd.Parameters.AddWithValue("@Pname", policy.PolicyName);
            connect.Open();
            cmd.Connection = connect;
            cmd.ExecuteNonQuery();
            connect.Close();
            return true;
        }

        internal bool PolicyNotExists(int policyId)
        {
            int count = 0;
            cmd.CommandText = "Select count(*) as total from PPolicy where policyId=@Pid";
            cmd.Parameters.AddWithValue("@Pid", policyId);
            connect.Open();
            cmd.Connection = connect;
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                count = (int)reader["total"];
            }
            connect.Close();
            if (count > 0)
            {
                return true;
            }
            return false;
        }

        public bool DeletePolicy(int policyId)
        {
            cmd.CommandText = " Delete from PPolicy where policyId = @Pid";
            cmd.Parameters.AddWithValue("@Pid", policyId);
            connect.Open();
            cmd.Connection = connect;
            cmd.ExecuteNonQuery();
            connect.Close();
            return true;
        }

       public List <Policy>GetAllPolicies()
        {
            List<Policy> policies = new List<Policy>();
            cmd.CommandText = "Select * from PPolicy";
            connect.Open();
            cmd.Connection = connect;
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Policy policy = new Policy ();
                policy.PolicyId = (int)reader["policyId"];
                policy.PolicyName = (string)reader["policyname"];
                policies.Add(policy);
            }
            connect.Close();
            return policies;

        }

        public Policy GetPolicy(int policyId)
        {
            Policy policy = null;
            cmd.CommandText = "Select * from PPolicy where policyId=@pid";
            cmd.Parameters.AddWithValue("@pid", policyId);
            connect.Open();
            cmd.Connection = connect;
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                policy = new Policy();
                policy.PolicyId = (int)reader["policyId"];
                policy.PolicyName = (string)reader["policyName"];

            }
            connect.Close();
            return policy;

        }
        public bool UpdatePolicy(Policy policy)
        {
            cmd.CommandText = "UPDATE PPolicy SET policyname = @newname WHERE policyId = @pid;";
            cmd.Parameters.AddWithValue("@pid", policy.PolicyId);
            cmd.Parameters.AddWithValue("@newname", policy.PolicyName);
            connect.Open();
            cmd.Connection = connect;
            cmd.ExecuteNonQuery();
            connect.Close();
            return true;

        }


    }
}
