﻿using InsuranceManagementSystemCC.InsuranceManagementApp;

namespace InsuranceManagementSystemCC
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Mainmodule insuranceManagementSystemApp = new Mainmodule(); 

           insuranceManagementSystemApp.Menu();
        }
    }
}
