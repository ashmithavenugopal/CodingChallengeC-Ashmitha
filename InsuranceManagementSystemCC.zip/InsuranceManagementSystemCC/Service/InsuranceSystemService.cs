﻿using InsuranceManagementSystemCC.Dao;
using InsuranceManagementSystemCC.Exceptions;
using InsuranceManagementSystemCC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceManagementSystemCC.Service
{
    public class InsuranceSystemService
    {
        private readonly InsuranceServiceImpl insuranceService;
       

        public InsuranceSystemService()
        {
            insuranceService = new InsuranceServiceImpl();
        }

        public void InsertPolicy(Policy policy)
        {
            
            insuranceService.CreatePolicy(policy);

            Console.WriteLine("Policy created successfully");
        }

        public void GetPolicyName(int policyId)
        {

            try
            {
                PolicyNotFoundException.PolicyNotFound(policyId);
                Policy policy = insuranceService.GetPolicy(policyId);
                Console.WriteLine(policy);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
       
        public void DisplayPolicyRecord()
        {
            List<Policy> policies  = insuranceService.GetAllPolicies();
            Console.WriteLine("P_iD  Name");
            foreach (Policy policy in policies)
            {
                Console.WriteLine(policy);
            }
        }

        public void UpdatePolicyRecord(Policy policy)
        {
            try
            {
                PolicyNotFoundException.PolicyNotFound(policy.PolicyId);
                insuranceService.UpdatePolicy(policy);
                Console.WriteLine("Policy updated");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void DeletePolicyRecord(int policyId)
        {
            PolicyNotFoundException.PolicyNotFound(policyId);
            insuranceService.DeletePolicy(policyId);
            Console.WriteLine("Policy Deleted ");

        }

    }
}
