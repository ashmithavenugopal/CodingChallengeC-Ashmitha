﻿using InsuranceManagementSystemCC.Dao;
using InsuranceManagementSystemCC.Models;
using InsuranceManagementSystemCC.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceManagementSystemCC.InsuranceManagementApp
{
    internal class Mainmodule
    {
        readonly InsuranceServiceImpl insuranceServiceImpl;

        public Mainmodule()
        {
            insuranceServiceImpl = new InsuranceServiceImpl();
        }
        public void Menu()
        {
            Console.WriteLine("Insurance Management System");
            Console.WriteLine("1. Create Policy");
            Console.WriteLine("2. Get policy");
            Console.WriteLine("3. Get All Policies");
            Console.WriteLine("4. Update Policy");
            Console.WriteLine("5. Delete Policy");
            Console.WriteLine("Enter your Input");
            int Menu = int.Parse(Console.ReadLine());

            InsuranceSystemService insuranceSystemService = new InsuranceSystemService(); 
            
            switch (Menu)
            {
                case 1:
                    Policy policy = new Policy();
                   
                    Console.WriteLine("Enter Policy Name: ");
                    string policyname = Console.ReadLine();
                    policy = new Policy()
                    {
                        PolicyName = policyname
                    };
                    insuranceSystemService.InsertPolicy(policy);
                         
                    break;
                case 2:
                    Console.WriteLine("Enter Policy id:");
                    int policyId = int.Parse(Console.ReadLine());
                    policy = new Policy()
                    {
                        PolicyId = policyId
                    };
                    insuranceSystemService.GetPolicyName(policyId);
                    break;

                case 3:
                   
                    Console.WriteLine("List of policy");
                    insuranceSystemService.DisplayPolicyRecord();

                    break;
                case 4:
                    
                    Console.WriteLine("Enter the Policy id to be changed");
                    int policyid = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Name to be changed:");
                    string newname = Console.ReadLine();
                    Policy policy1 = new Policy()
                    {
                        PolicyId = policyid,
                        PolicyName = newname
                    };


                    insuranceSystemService.UpdatePolicyRecord(policy1);
                    break;
                case 5:
                    Console.WriteLine("Enter the Policy id to be deleted");
                    int deletepolicyid = int.Parse(Console.ReadLine());
                    policy = new Policy()
                    {
                        PolicyId = deletepolicyid
                    };

                    insuranceSystemService.DeletePolicyRecord(deletepolicyid);

                    break;


                default:
                    Console.WriteLine("Try again");
                    break;
            }
            

        }
    }
}
