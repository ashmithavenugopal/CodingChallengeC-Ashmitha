﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceManagementSystemCC.Models
{
    public class Client
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string ContactInfo { get; set; }
        public int PolicyId { get; set; }

        // Default constructor
        public Client()
        {
        }

        // Overloaded constructor
        public Client(int clientId, string clientName, string contactInfo, int policyId)
        {
            ClientId = clientId;
            ClientName = clientName;
            ContactInfo = contactInfo;
            PolicyId = policyId;
        }

        public void PrintClientInfo()
        {
            Console.WriteLine($"Client ID: {ClientId}");
            Console.WriteLine($"Client Name: {ClientName}");
            Console.WriteLine($"Contact Info: {ContactInfo}");
            Console.WriteLine($"Policy ID: {PolicyId}");
        }

        public override string ToString()
        {
            return $"{ClientId} {ClientName} {ContactInfo} {PolicyId}";
        }
    }
}
