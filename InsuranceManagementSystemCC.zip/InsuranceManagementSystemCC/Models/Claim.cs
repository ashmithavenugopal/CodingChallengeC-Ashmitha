﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceManagementSystemCC.Models
{
    public class Claim
    {
        public int ClaimId { get; set; }
        public string ClaimNumber { get; set; }
        public DateOnly DateFiled { get; set; }
        public decimal ClaimAmount { get; set; }
        public string Status { get; set; }
        public int PolicyId { get; set; }
        public int ClientId { get; set; }

        // Default constructor
        public Claim()
        {
        }
        public Claim(int claimId, string claimNumber, DateOnly dateFiled, decimal claimAmount, string status, int policyId, int clientId)
        {
            ClaimId = claimId;
            ClaimNumber = claimNumber;
            DateFiled = dateFiled;
            ClaimAmount = claimAmount;
            Status = status;
            PolicyId = policyId;
            ClientId = clientId;
        }

        public void PrintClaimInfo()
        {
            Console.WriteLine($"Claim ID: {ClaimId}");
            Console.WriteLine($"Claim Number: {ClaimNumber}");
            Console.WriteLine($"Date Filed: {DateFiled}");
            Console.WriteLine($"Claim Amount: {ClaimAmount}");
            Console.WriteLine($"Status: {Status}");
            Console.WriteLine($"Policy ID: {PolicyId}");
            Console.WriteLine($"Client ID: {ClientId}");
        }

        public override string ToString()
        {
            return $"{ClaimId} {ClaimNumber} {DateFiled} {ClaimAmount} {Status} {PolicyId} {ClientId}";
        }

    }
}
