﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceManagementSystemCC.Models
{
    public class Payment
    {
        public int PaymentId { get; set; }
        public DateTime PaymentDate { get; set; }
        public decimal PaymentAmount { get; set; }
        public int ClientId { get; set; }

        // Default constructor
        public Payment()
        {
        }

        // Overloaded constructor
        public Payment(int paymentId, DateTime paymentDate, decimal paymentAmount, int clientId)
        {
            PaymentId = paymentId;
            PaymentDate = paymentDate;
            PaymentAmount = paymentAmount;
            ClientId = clientId;
        }

        public void PrintPaymentInfo()
        {
            Console.WriteLine($"Payment ID: {PaymentId}");
            Console.WriteLine($"Payment Date: {PaymentDate}");
            Console.WriteLine($"Payment Amount: {PaymentAmount}");
            Console.WriteLine($"Client ID: {ClientId}");
        }

        public override string ToString()
        {
            return $"{PaymentId} {PaymentDate} {PaymentAmount} {ClientId}";
        }
    }
}
