﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceManagementSystemCC.Models
{
    public class Policy
    {
        public int PolicyId { get; set; }
        public string PolicyName { get; set; }

        // Default constructor
        public Policy()
        {
        }

        // Overloaded constructor
        public Policy(int policyId, string policyName)
        {
            PolicyId = policyId;
            PolicyName = policyName;
        }

        //public void PrintPolicyInfo()
        //{
        //    Console.WriteLine($"Policy ID: {PolicyId}");
        //    Console.WriteLine($"Policy Name: {PolicyName}");
        //}

        public override string ToString()
        {
            return $"{PolicyId} {PolicyName} ";
        }
    }
}
